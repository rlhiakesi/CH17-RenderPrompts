CH17-P032: produce IAKESI-CH17-032-art.png, -lettering.png, -text.txt; 1024x1536; CSP ALL CAPS; no page numbers or English inside artwork.
